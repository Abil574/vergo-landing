
import React from "react";

export default function VergoLandingPage() {
  return (
    <main className="min-h-screen bg-white text-gray-800 font-sans">
      <header className="flex items-center justify-between px-8 py-6 shadow-md">
        <h1 className="text-2xl font-bold text-blue-600">Vergo</h1>
        <nav className="space-x-6">
          <a href="#services" className="hover:text-blue-600">Услуги</a>
          <a href="#how-it-works" className="hover:text-blue-600">Как работает</a>
          <a href="#faq" className="hover:text-blue-600">FAQ</a>
          <a href="#contact" className="hover:text-blue-600">Контакты</a>
        </nav>
        <button className="bg-blue-600 text-white px-4 py-2 rounded-xl hover:bg-blue-700 transition">
          Попробовать AI
        </button>
      </header>
      <section className="text-center px-4 py-20 bg-gray-50">
        <h2 className="text-4xl font-bold mb-4">Ваш личный налоговый помощник на базе ИИ</h2>
        <p className="text-lg text-gray-600 mb-6">
          Получайте точные налоговые консультации 24/7. Быстро. Безопасно. Конфиденциально.
        </p>
        <button className="bg-blue-600 text-white px-6 py-3 rounded-xl text-lg hover:bg-blue-700 transition">
          Начать консультацию
        </button>
      </section>
      <section id="services" className="px-6 py-16">
        <h3 className="text-2xl font-semibold mb-6 text-center">Что умеет Vergo?</h3>
        <div className="grid md:grid-cols-3 gap-6 text-center">
          <div className="bg-white rounded-2xl shadow p-6">
            <h4 className="font-bold mb-2">AI-Консультант</h4>
            <p>Задайте налоговый вопрос и получите мгновенный ответ от ИИ.</p>
          </div>
          <div className="bg-white rounded-2xl shadow p-6">
            <h4 className="font-bold mb-2">Калькулятор налогов</h4>
            <p>Узнайте, сколько налогов вы должны заплатить по закону.</p>
          </div>
          <div className="bg-white rounded-2xl shadow p-6">
            <h4 className="font-bold mb-2">Документы и отчётность</h4>
            <p>Помощь с подготовкой деклараций и проверкой правильности расчётов.</p>
          </div>
        </div>
      </section>
      <section id="how-it-works" className="bg-blue-50 px-6 py-16">
        <h3 className="text-2xl font-semibold mb-6 text-center">Как это работает?</h3>
        <ol className="max-w-3xl mx-auto space-y-4 text-gray-700">
          <li><strong>1.</strong> Вы задаёте вопрос через форму или чат.</li>
          <li><strong>2.</strong> Наш AI анализирует закон, нормы и вашу ситуацию.</li>
          <li><strong>3.</strong> Вы получаете чёткий и полезный ответ.</li>
        </ol>
      </section>
      <footer id="contact" className="bg-gray-900 text-white px-6 py-12">
        <div className="text-center">
          <h4 className="text-xl font-semibold mb-2">Контакты</h4>
          <p>Email: support@vergo.az</p>
          <p>Telegram: @VergoBot</p>
          <p className="mt-4 text-sm text-gray-400">© 2025 Vergo. Все права защищены.</p>
        </div>
      </footer>
    </main>
  );
}
